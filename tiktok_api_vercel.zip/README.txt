# TikTok Downloader API (for Vercel)

## 🚀 Deploy on Vercel

1. Go to https://vercel.com
2. Click **Add New Project**
3. Import this folder (ZIP) from your GitHub or upload manually
4. Vercel will auto-detect Node.js app and deploy your API

### API Endpoint Example:
https://your-project-name.vercel.app/api/tiktok?url=PASTE_TIKTOK_LINK

---
✅ Made for free TikTok video download without watermark
